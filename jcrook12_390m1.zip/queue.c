#include <stdio.h>  // printf
#include <stdlib.h> // malloc, free, abort
#include <string.h> // strncpy

#include "queue.h"

// Allocates memory for the queue (the data* pointer) and initializes all
// parts of the data structure. Prints out an error message if malloc() fails
// and calls assert(false) to print-out line-number information and die.
// The queue is empty after initialization. To fill the queue with known
// values (e.g. zeros), call queue_overwritePush() up to queue_size() times.
void queue_init(queue_t *q, queue_size_t size, const char *name)
{
    // Always points to the next open slot.
    q->indexIn = 0;
    // Always points to the next element to be removed
    // from the queue (or "oldest" element).
    q->indexOut = 0;
    // Keep track of the number of elements currently in queue.
    q->elementCount = 0;
    // Queue capacity.
    q->size = size;
    // Points to a dynamically-allocated array.
    q->data = malloc(size * sizeof(queue_data_t));
    if (q->data == NULL) abort();
    // True if queue_pop() is called on an empty queue. Reset
    // to false after queue_push() is called.
    q->underflowFlag = false;
    // True if queue_push() is called on a full queue. Reset to
    // false once queue_pop() is called.
    q->overflowFlag = false;
    // Name for debugging purposes.
    strncpy(q->name, name, QUEUE_MAX_NAME_SIZE);
    q->name[QUEUE_MAX_NAME_SIZE-1] = '\0';
}

// Get the user-assigned name for the queue.
const char *queue_name(queue_t *q)
{
    return q->name;
}

// Returns the capacity of the queue.
queue_size_t queue_size(queue_t *q)
{
    return q->size;
}

// Returns true if the queue is full.
bool queue_full(queue_t *q)
{
    return q->elementCount==q->size;
}

// Returns true if the queue is empty.
bool queue_empty(queue_t *q)
{
    return q->elementCount==0;
}

// If the queue is not full, pushes a new element into the queue and clears the
// underflowFlag. IF the queue is full, set the overflowFlag, print an error
// message and DO NOT change the queue.???
void queue_push(queue_t *q, queue_data_t value)
{
    // Check for a full queue
    if (queue_full(q)) {
        // IF the queue is full, set the overflowFlag, print an error
        // message and DO NOT change the queue.
        q->overflowFlag=true;
        printf("ERROR in queue_push(): Queue is full. Unable to push.\n");
        return;
    }

    // If the queue is not full, push the new element to the queue and clear the
    // underflowFlag.
    // Push to queue using MAGIC!
    q->data[q->indexIn] = value;

    // Increment element number and indexIn
    q->elementCount++;

    //q->indexIn = (q->indexIn + 1) % q->size;
    q->indexIn++;
    if ((q->indexIn)>=q->size) {
        q->indexIn=0;
    }

    // Reset to false once queue_push is called
    q->underflowFlag = false;
}

// If the queue is not empty, remove and return the oldest element in the queue.
// If the queue is empty, set the underflowFlag, print an error message, and DO
// NOT change the queue.???
queue_data_t queue_pop(queue_t *q)
{
    // Check for an empty queue
    if (queue_empty(q)) {
        // IF the queue is empty, set the underflowFlag, print an error
        // message and DO NOT change the queue.
        q->underflowFlag=true;
        printf("ERROR in queue_pop(): Queue is empty. Unable to pop.\n");
        return QUEUE_RETURN_ERROR_VALUE;
    }

    // If the queue is not empty, remove and return the oldest element in the queue.
    // Pop from queue using MAGIC!
    queue_data_t extractedData = q->data[q->indexOut];

    // Decrement element number and increment indexOut
    q->elementCount--;
    //q->indexOut = (q->indexOut + 1) % q->size;
    q->indexOut++;
    if ((q->indexOut)>=q->size) {
        q->indexOut=0;
    }


    // Reset to false once queue_push is called
    q->overflowFlag = false;

    // Return a queue_data_t value???
    return extractedData;
}

// If the queue is full, call queue_pop() and then call queue_push().
// If the queue is not full, just call queue_push().???
void queue_overwritePush(queue_t *q, queue_data_t value)
{
    // If the queue is full, call queue_pop() and then call queue_push().
    if (queue_full(q)) {
        queue_pop(q);
    }

    // If the queue is not full, just call queue_push().
    queue_push(q, value);
}

// Provides random-access read capability to the queue.
// Low-valued indexes access older queue elements while higher-value indexes
// access newer elements (according to the order that they were added). Print a
// meaningful error message if an error condition is detected.
queue_data_t queue_readElementAt(queue_t *q, queue_index_t index)
{
    // If the index is greater than or equal to q->size,
    // return the appropriate error message
    if (index >= q->size) {
        printf("ERROR in queue_readElementAt(): Index out of bounds.\n");
        return QUEUE_RETURN_ERROR_VALUE;
    }

    // Return data using MAGIC!
    queue_index_t actualIndex = (index + q->indexOut) % q->size;
    return q->data[actualIndex];
}

// Returns a count of the elements currently contained in the queue.
queue_size_t queue_elementCount(queue_t *q)
{
    return q->elementCount;
}

// Returns true if an underflow has occurred (queue_pop() called on an empty
// queue).
bool queue_underflow(queue_t *q)
{
    return q->underflowFlag;
}

// Returns true if an overflow has occurred (queue_push() called on a full
// queue).
bool queue_overflow(queue_t *q)
{
    return q->overflowFlag;
}

// Frees the storage that you malloc'd before.
void queue_garbageCollect(queue_t *q)
{
    free(q->data);
}